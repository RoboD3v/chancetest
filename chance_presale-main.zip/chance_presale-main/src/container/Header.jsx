import React, { useState, useEffect, useCallback } from "react";
import { useAccount, useNetwork, useSwitchNetwork } from "wagmi";
import { useWeb3Modal } from "@web3modal/react";
import styles from "../styles/container/Container.module.scss";
import mainLogo from "../icons/logo.png";


const Header = () => {
    const [isActive] = useState();
    const { address, isConnected } = useAccount();
    const { open } = useWeb3Modal();
    const onConnect = async () => {
        await open();
    };
    const { isLoading, pendingChainId, switchNetwork } = useSwitchNetwork()
    const { chain } = useNetwork();
    useEffect(() => {
        const switchChain = async () => {
            try {
                switchNetwork?.(97)
            } catch (e) {
                console.error(e)
            }
        }
        if (isConnected === true) {
            if (chain.id !== 97)
                switchChain();
        }
    }, [isConnected, chain, switchNetwork])

    return (
        <div>
            <div className={styles.HeaderContainer}>
                <div className={styles.HeaderContainer}>
                    <section className={styles.BalanceSection}>
                        <img src={mainLogo} alt="logo" />
                        
                    </section>
                    <section className={styles.ButtonContainer}>
                        <div className="connectButtonBox">
                            {!isConnected ?
                                <>
                                    <button className="ConnectButton" type="submit" onClick={() => {
                                        onConnect();
                                    }}>Enter App / Connect</button>
                                </>
                                :
                                <section className={styles.ConnectWalletSection}>
                                    {chain?.id === 97 ?
                                        <button
                                            className="ConnectButton" type="submit"
                                            onClick={() => onConnect()}
                                        >
                                            {address.slice(0, 5) + '...' + address.slice(-5)}
                                        </button>
                                        :
                                        <button
                                            className="ConnectButton" type="submit"
                                            onClick={() => switchNetwork?.(97)}
                                        >
                                            {'To BSC'}
                                            {isLoading && pendingChainId === 97 && ' (switching)'}
                                        </button>
                                    }
                                </section>
                            }
                        </div>
                    </section>
                </div>
            </div>
            <div className={styles.HeaderLine}></div>
        </div>
    );
};

export default Header;