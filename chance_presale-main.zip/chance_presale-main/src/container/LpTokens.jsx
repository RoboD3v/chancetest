import React, { useState, useEffect } from 'react'
import { ethers } from 'ethers'
import { useAccount, useNetwork, useSwitchNetwork } from "wagmi";
import '../App.css'
import LPTokenAbi from '../config/LPTokenAbi.json'
import LPLockerAbi from '../config/LPLockerAbi.json'
import TokenAbi from '../config/TokenAbi.json'
import "../styles/LockContainer.css";
import Input from "../components/Input.tsx";
import Footer from "../container/Footer.jsx";
import { isAddress } from '../utils/web3.ts'
import { readContract } from '@wagmi/core'
import BounceLoader from "react-spinners/BounceLoader";
import { Badge, Space } from "antd";
import { useWeb3Modal } from "@web3modal/react";
// import Header from "../container/Header.jsx";

const App = () => {
    const { address, isConnected } = useAccount();
    const { chain } = useNetwork();
    const [lpAddress, setLpAddress] = useState('');
    let [loading, setLoading] = useState(false);
    const LPLockerAddress = "0x4477f9fd9c65b69b52a59b4fca772179be3c67b3";

    const { open } = useWeb3Modal();
    const onConnect = async () => {
        await open();
    };
    const { switchNetwork } = useSwitchNetwork()
    const [length, setLength] = useState(0);
    let [LpDatas, setLpDatas] = useState();

    useEffect(() => {
        const switchChain = async () => {
            try {
                switchNetwork?.(5)
            } catch (e) {
                console.error(e)
            }
        }
        if (isConnected === true) {
            if (chain.id !== 5)
                switchChain();
        }
    }, [isConnected, chain?.id, switchNetwork])

    useEffect(() => {
        const FetchBadgeData = async () => {
            try {
                const length = await readContract({ address: LPLockerAddress, abi: LPLockerAbi, functionName: 'getUserNumLockedTokens', args: [address] });
                setLength(length);
            } catch (e) {
                console.error(e)
            }
        }
        if (isConnected === true && chain?.id === 5) {
            FetchBadgeData();
        }
    }, [isConnected, address, chain])


    useEffect(() => {
        const uselpTokenCheck = async () => {
            try {
                let LpData = [];
                setLpDatas(LpData);
                setLoading(true);
                const LpLength = await readContract({ address: LPLockerAddress, abi: LPLockerAbi, functionName: 'getNumLocksForToken', args: [lpAddress] });
                const LockedTokenAddress1 = await readContract({ address: lpAddress, abi: LPTokenAbi, functionName: 'token0' });
                const LockedTokenAddress2 = await readContract({ address: lpAddress, abi: LPTokenAbi, functionName: 'token1' });
                const symbol1 = await readContract({ address: LockedTokenAddress1, abi: TokenAbi, functionName: 'symbol' });
                const symbol2 = await readContract({ address: LockedTokenAddress2, abi: TokenAbi, functionName: 'symbol' });
                if (Number(LpLength) > 0) {
                    for (var i = 0; i < Number(LpLength); i++) {
                        const LpDatas = await readContract({ address: LPLockerAddress, abi: LPLockerAbi, functionName: 'tokenLocks', args: [lpAddress, i] });
                        if (Number(LpDatas[1]) !== 0) {
                            LpData.push(
                                <>
                                    {i === 0 ?
                                        <div className='accountData'>
                                            <div className='accountDetail'>
                                                <p><b>{symbol1}</b> / {symbol2}</p>
                                            </div>
                                        </div>
                                        :
                                        <></>
                                    }
                                    <div className='withdrawContent'>
                                        <div className='accountData'>
                                            <div className='accountDetail'>
                                                <p>Locked Time : &nbsp;</p>
                                                <p>{new Date(Number(LpDatas[0]) * 1000).toLocaleString()}</p>
                                            </div>
                                            <div className='accountDetail'>
                                                <p>UnLock Time : &nbsp;</p>
                                                <p>{new Date(Number(LpDatas[3]) * 1000).toLocaleString()}</p>
                                            </div>
                                        </div>
                                        <div className='accountData'>
                                            <div className='accountDetail'>
                                                <p>Locked Amount :  &nbsp;</p>
                                                <p>{Number(ethers.utils.formatEther(LpDatas[1])).toFixed(3)}</p>
                                            </div>
                                            <div className='accountDetail'>
                                                <p>Owner :  &nbsp;</p>
                                                <p>{LpDatas[5].slice(0, 5) + '...' + LpDatas[5].slice(-3)}</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="bnbPoolContentLine"></div>
                                </>
                            )
                        }
                    }
                    setLpDatas(LpData);
                } else {
                    <p>There is no this LP tokens</p>
                }
                setLoading(false);
            } catch (e) {
                console.error(e)
            }
        }
        if ((isAddress(lpAddress))) {
            uselpTokenCheck();
        }
    }, [lpAddress, address])


    return (
        <main>
             {/* <Header /> */}
            {/* <div>
                <div className={styles.HeaderContainer}>
                    <div className={styles.HeaderContainer}>
                        <section className={styles.BalanceSection}>
                            <img src={mainLogo} alt="logo" />
                            <section className={styles.HeaderTextContainer}>
                                <a className={styles.HeaderTitleRouter} href={"/"}><span className={currentPath === '/' ? styles.HeaderSelected : styles.HeaderUnselected}>Dashboard</span></a>
                                <a className={styles.HeaderTitleRouter} href={"/lptokens"}><span className={currentPath === '/lptokens' ? styles.HeaderSelected : styles.HeaderUnselected}>Locked LPs</span></a>
                                <Space size="middle" style={{ marginRight: "20px" }}>
                                    {Number(length) > 0 ?
                                        <>
                                            <Badge count={length}>
                                                <a className={styles.HeaderTitleRouter} href={"/account"}><span className={currentPath === '/account' ? styles.HeaderSelected : styles.HeaderUnselected}>Account</span></a>
                                            </Badge>
                                        </>
                                        :
                                        <></>
                                    }
                                </Space>

                            </section>
                        </section>
                        <section className={styles.ButtonContainer}>
                            <div className="connectButtonBox">
                                {!isConnected ?
                                    <>
                                        <button className="ConnectButton" type="submit" onClick={() => {
                                            onConnect();
                                        }}>Enter App / Connect</button>
                                    </>
                                    :
                                    <section className={styles.ConnectWalletSection}>
                                        {chain?.id === 5 ?
                                            <button
                                                className="ConnectButton" type="submit"
                                                onClick={() => onConnect()}
                                            >
                                                {address.slice(0, 5) + '...' + address.slice(-5)}
                                            </button>
                                            :
                                            <button
                                                className="ConnectButton" type="submit"
                                                onClick={() => switchNetwork?.(5)}
                                            >
                                                {'To Goerli'}
                                                {isLoading && pendingChainId === 5 && ' (switching)'}
                                            </button>
                                        }
                                    </section>
                                }
                            </div>
                        </section>
                    </div>
                </div>
                <div className={styles.HeaderLine}></div>
            </div> */}
            <div className="GlobalContainer">
                {address ?
                    chain?.id === 5 ?
                        <div className="MainDashboard">
                            <section className="ContactBox">
                                <>
                                    <section className="ContractContainer">
                                        <section className="DepositBoxHeader">
                                            <p className="ContractContentTextTitle">LP Tokens</p>
                                        </section>
                                        <section className='HeaderContent'>
                                            <p className='HeaderText'>Use the locker to prove to investors you have locked liquidity. If you are not a token developer, this section is almost definitely not for you.</p>
                                        </section>
                                        <section className='inputPanel'>
                                            <section className='inputPanelHeader'>
                                                <Input
                                                    placeholder="Uniswap V2 pair address..."
                                                    label=""
                                                    type="string"
                                                    changeValue={setLpAddress}
                                                    value={lpAddress}
                                                    style={{
                                                        'border-style': 'none'
                                                    }}
                                                />
                                            </section>
                                        </section>
                                        {loading === false ?
                                            LpDatas !== undefined ?
                                                <section className="LpDataContainer">{LpDatas}</section>
                                                :
                                                <></>
                                            :
                                            <div className='LoadingBox'>
                                                <p className='Text1'>
                                                    Fetching...
                                                </p>
                                                <BounceLoader
                                                    color={'#36d7b7'}
                                                    loading={loading}
                                                    size={50}
                                                    aria-label="Loading Spinner"
                                                    data-testid="loader"
                                                />
                                            </div>
                                        }
                                        <div className="bnbPoolContentLine"></div>
                                    </section>
                                </>
                            </section>
                        </div>
                        :
                        <section className="ConnectWalletBox">
                            <p className="FirstNote">Please change chain</p>
                            <div className="ConnectWalletBoxButton">
                            </div>
                        </section>
                    :
                    <section className="ConnectWalletBox">
                        <p className="FirstNote">Please connect wallet first</p>
                        <div className="ConnectWalletBoxButton">
                        </div>
                    </section>
                }
            </div>
            <Footer />
        </main >
    )
}

export default App
