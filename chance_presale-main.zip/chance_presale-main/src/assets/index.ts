import logo_Vault from './logo_Vault.png'




export { logo_Vault };